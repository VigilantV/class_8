# دو خط پایین برای خوانایی بهتر خروجی هستند
import os
os.system("cls")

# تعریف دو متغیر دارای عدد
a = 33
b = 200

# شرط تک حالته
if b > a:
    print("b is greater than a")

# شرط چند حالته
if b > a:
    print("b is greater than a")
elif a > b:
    print("a is greater than b")

# شرط چند حالته همراه با عبارت در غیر این صورت
if b > a:
    print("b is greater than a")
elif a > b:
    print("a is greater than b")
else:
    print("a and b are equal")


# مثالی دیگر
myFavortieColor = input("enter your favortie color: ")

if myFavortieColor == "red":
    print("your favorite color is red")
elif myFavortieColor == "blue":
    print("your favorite color is blue")
elif myFavortieColor == "green":
    print("your favorite color is green")
else:
    print("your favorite color is not in the list!")
