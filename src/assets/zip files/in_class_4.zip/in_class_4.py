import os
os.system("cls")

#چاپ اعداد 1 تا 10
# for i in range(10):
#     print(i + 1, end=" ")

#چاپ تعداد اعداد زوج بین 1 تا 30
# for i in range(30):
#     if i % 2 == 0 and i != 0:
#         print(i, end=" ")

# چاپ اعداد بین 10 تا 20
# for i in range(10, 21):
#     print(i, end=" ")
      # یا
# for i in range(9, 20):
#     print(i + 1, end=" ")

#فرمول نویسی و محاسبات ریاضی
# import math
# radius = int(input("enter a number: "))
# print(f"masahat dayere ba shoa {radius} mishavad: {math.pi * radius * radius} ")
# print(f"mohit dayere ba shoa {radius} mishavad: {math.pi * radius * 2} ")

