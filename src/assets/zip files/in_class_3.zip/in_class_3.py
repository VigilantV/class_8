# دو خط پایین برای خوانایی بهتر خروجی هستند
import os
os.system("cls")

# number_1 = int(input("enter your first number: "))
# number_2 = int(input("enter your second number: "))

# result = number_1 * number_2

# if result % 2 == 1:
#     print("adad fard hast")
# else:
#     print("adad zoj hast")

num_1 = int(input("enter your first number: "))
num_2 = int(input("enter your second number: "))

if num_1 * num_2 < 50:
    print("hasel zarbe " + str(num_1) + " va " + str(num_2) + " kamtar az 50 hast")
elif num_1 * num_2 >= 50 and num_1 * num_2 <= 100:
    print("hasel zarbe " + str(num_1) + " va " + str(num_2) + " bozorgtar mosavi 50 va kuchek tar mosavi 100 hast")
else:
    print("hasel zarbe " + str(num_1) + " va " + str(num_2) + " bozorgtar az 100 hast")
