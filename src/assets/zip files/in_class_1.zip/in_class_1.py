# دو خط پایین برای خوانایی بهتر خروجی هستند
import os
os.system("cls")

print("Hi Class!")
print('Hi Class!')

# legal variable names
myvar = "value"
my_var = "value"
myVar = "value"
MYVAR = "value"
myvar2 = "value"

# illegal variable names
#  2myvar = "value"
#  my-var = "value"
#  my var = "value"

text = input("write some text: ")
print('this is my text: ' + text)

number = input("write a number: ")
print('this is your number: ' + number)

newCalculation = int(number) * 2 + 5
print('new calculations result: ' + str(newCalculation))
