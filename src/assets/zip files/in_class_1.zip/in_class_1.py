import os
os.system("cls")

print("Hi Class!")
print('Hi Class!')

text = input("write some text: ")
print(text)

result = str(4) + " apple"
print(result)

# illegal variable names
#  2myvar = "value"
#  my-var = "value"
#  my var = "value"

# legal variable names
myvar = "value"
my_var = "value"
_my_var = "value"
myVar = "value"
MYVAR = "value"
myvar2 = "value"

# a, b, c = 1, 2, 3
# print(a)
# print(b)
# print(c)

# x = y = z = "Orange"
# print(x, y, z)

# x = "Hello World"  # "Hello World", -20, 12.5, True
# print(type(x))

# x = int(1)   # x will be 1
# y = int(2.8) # y will be 2
# z = int("3") # z will be 3

# x = float(1)     # x will be 1.0
# y = float(2.8)   # y will be 2.8
# z = float("3")   # z will be 3.0
# w = float("4.2") # w will be 4.2

# x = str("s1")  # x will be 's1'
# y = str(2)    # y will be '2'
# z = str(3.0)  # z will be '3.0'

# print(10 > 9)
# print(10 == 9)
# print(10 < 9)
# print(bool("Hello"))
# print(bool(15))
# Any string is True, except empty strings.
# Any number is True, except 0.

# Python Operators###### https://www.w3schools.com/python/python_operators.asp
