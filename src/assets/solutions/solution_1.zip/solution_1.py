import os
os.system("cls")

name = input("enter your name: ")
age = input("enter your age: ")
print("Hi, my name is " + name + " and im " + age + " years old.")
print("--------------------   --------------------")
print("Allright " + name + """. I have a challenge for you! I want you to multiply your age
       by 5 and subtract number 10 from it and then show me the result like below:""")
print("result: " + age + " * 5 - 10 = " + str(int(age)*5-10))
